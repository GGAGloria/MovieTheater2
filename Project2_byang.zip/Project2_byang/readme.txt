2. a. Version of Node.js: v10.13.0
      Version of Express.js: 6.4.1
      Version of MongoDB: v4.0.4
b. to run:  node Server.js
c. All finished.
